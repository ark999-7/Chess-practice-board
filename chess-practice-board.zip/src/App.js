import ChessPracticeBoard from "./ChessPracticeBoard";

function App() {
  return (
    <div className="App">
      <ChessPracticeBoard />
    </div>
  );
}

export default App;